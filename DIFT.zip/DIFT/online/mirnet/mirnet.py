# -*- coding: utf-8 -*-
"""
Created on Fri Apr  8 19:01:18 2022

@author: K K's NOTEBOOK
"""
import tensorflow as tf
import numpy as np
from tensorflow.keras.models import load_model
from matplotlib import pyplot as plt
from PIL import Image
from online.mirnet.utils import closest_number


image_resize_factor: float = 1.
    
    




def llt(src):
    print("llt")
    original_image = Image.open(src)
    image_resize_factor: float = 1.
    print("predicting")
    model = load_model('S:\DIFT\online\mirnet\inf.h5')
    print("Loading done")
    width, height = original_image.size
    target_width, target_height = (
        closest_number(width // image_resize_factor, 4),
        closest_number(height // image_resize_factor, 4)
    )
    print("cl num")
    original_image = original_image.resize(
        (target_width, target_height), Image.ANTIALIAS
    )
    image = tf.keras.preprocessing.image.img_to_array(original_image)
    image = image.astype('float32') / 255.0
    image = np.expand_dims(image, axis=0)
    output = model.predict(image)
    output_image = output[0] * 255.0
    output_image = output_image.clip(0, 255)
    output_image = output_image.reshape(
        (np.shape(output_image)[0], np.shape(output_image)[1], 3)
    )
    output_image = Image.fromarray(np.uint8(output_image))
    original_image = Image.fromarray(np.uint8(original_image))
    output_image.save(src)
