from http.client import HTTPResponse
from django.shortcuts import render
from django.http.response import HttpResponseRedirect
import sys

import cv2 as cv
from online.models import image_base
import os 
from online.mirnet.mirnet import llt
from online.ESRGANupscale.test import highres
#from online.recolor.Deoldify import recolour1

import tensorflow as tf
from tensorflow.keras.models import load_model
from PIL import Image
import numpy as np
import keras

n = 230

def index(request):
    return render(request, 'index.html')
# Create your views here.
def process(request):
    if request.method == 'POST':
        ph_no = request.POST['phone']
        img_data = request.FILES['photo']
        option_ = request.POST['options']
        try:
            image_base.objects.create(image=img_data, contact=ph_no)
            data = image_base.objects.get(contact=ph_no)
            print( type(option_), option_ )

            sobel(data, option_)
            return render(request, 'done.html',{"data":data})
        except:
            return render(request, 'failed.html')

    
def sobel(data, opt):
    scale = 1
    delta = 0
    ddepth = cv.CV_16S
    # Load the image
    path = "S:\DIFT"+data.image.url
    #backup = "S:/server_mode/server/backup"+data.image.url
    print(opt)

    if int(opt)==3:
        denoise(path)

    if int(opt)==2:
        llt(path)

    if int(opt)==1:
        highres(path)
    '''
    if int(opt)==4:
        print("rec")
        recolour1(path)
    '''
    if int(opt)==5:
        sharp(path)
        
    if int(opt)==6:
        secret(path)
    print("done")
    #cv.imwrite(backup,src)


def denoise(src):
    img_1 = cv.imread(src)
    dst_1= cv.fastNlMeansDenoisingColored(img_1, None, 10, 10, 7, 15)
    cv.imwrite(src,dst_1)
    pass 
    
def sharp(src):
    image = cv.imread(src, flags=cv.IMREAD_COLOR)
    kernel = np.array([[0, -1, 0],
                   [-1, 5,-1],
                   [0, -1, 0]])
    image_sharp = cv.filter2D(src=image, ddepth=-1, kernel=kernel)
    cv.imwrite(src, image_sharp)
    pass

def secret(src):
    img = cv.imread(src, cv.IMREAD_COLOR)
    print("initiated")
    gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
    print("Loaded")
    for i in range(2,len(gray[0])-1):
        for j in range(2,len(gray[:][0])-1):
            if (abs(abs(gray[i][j]-gray[i-1][j])-abs(gray[i][j]-gray[i+1][j]))>n) :
                gray[i][j] = 255
            if (abs(abs(gray[i][j]-gray[i][j-1])-abs(gray[i][j]-gray[i][j+1]))>n) :
                gray[i][j] = 255
            else :
                gray[i][j] = 0
    print("Secret Done")
    cv.imwrite(src,gray)
    
    