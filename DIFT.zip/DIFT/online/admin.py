from django.contrib import admin

# Register your models here.
from online.models import image_base

admin.site.register(image_base)