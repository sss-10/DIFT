from online.recolor.deoldify import device
from online.recolor.deoldify.device_id import DeviceId
from online.recolor.deoldify.visualize import *
from matplotlib import pyplot as plt
import torch 
def recolour1(path):
    print("called")
    device.set(device=DeviceId.GPU0)
    print("id set")
    plt.style.use('dark_background')
    torch.backends.cudnn.benchmark=True
    colorizer = get_image_colorizer(artistic=True)
    render_factor = 35
    input_data = path
    output_data = None
    output_data = colorizer.plot_transformed_image(path=input_data, render_factor=render_factor, compare=True)
