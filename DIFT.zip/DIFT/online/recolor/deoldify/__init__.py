from online.recolor.deoldify._device import _Device

device = _Device()