# -*- coding: utf-8 -*-
"""
Created on Thu Jun  2 01:44:16 2022

@author: K K's NOTEBOOK
"""
# Import other dependencies
import cv2
import tensorflow as tf
from layers import L1Dist
import os
import numpy as np

model = tf.keras.models.load_model('siamesemodel.h5', custom_objects={'L1Dist':L1Dist})


def preprocess(file_path):
    # Read in image from file path
    byte_img = tf.io.read_file(file_path)
    # Load in the image 
    img = tf.io.decode_jpeg(byte_img)
    
    # Preprocessing steps - resizing the image to be 100x100x3
    img = tf.image.resize(img, (100,100))
    # Scale image to be between 0 and 1 
    img = img / 255.0
    
    # Return image
    return img

im1 = preprocess("1.jpg")
im2 = preprocess("2.jpg")

result = model.predict(list(np.expand_dims([im1, im2], axis=1)))
print(result)