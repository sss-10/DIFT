#########################################################
#                                                       #
#            ImPoS : Image Processing System            #
#                                                       #
#########################################################



*********************************************************
              * Software Requirements *
              *************************
1. Anaconda for Machine Learning part
2. Visual Studio Code for Server part
3. Google Colab Pro for Training





*********************************************************
INSTALL THESE LIBRARIES IN ANACONDA BASE ENVIRONMENT


fastai==1.0.51
tensorboardX==1.6
ffmpeg-python
youtube-dl>=2019.4.17
jupyterlab
opencv-python>=3.3.0.10
pillow>=8.0.0
gdown==3.12.2
matplotlib==3.3.3
streamlit==0.74.1
tensorflow==2.4.0
wandb==0.10.14
numpy~=1.19.5
django==4.0.3


INSTALL Torch as pr your system


*************************************************
           *INSTALLATION PROCEDURE *
           *************************

1. Put the DIFT folder into S: directory
2. Open Anaconda cmd
3. Go to DIFT dir
4. Run command "python manage.py runserver"
5. Visit "127.0.0.1:8000" in Browser
6. Enjoy to system





##################################################

For feedback or any help, plese contact us on
Ph.no. 8840904029
Email: sashankshekharshukla@gmai.com

###################################################

Thankyou, have a nice day!
             