# -*- coding: utf-8 -*-
"""
Created on Tue Apr  5 23:31:35 2022

@author: K K's NOTEBOOK
"""

from tkinter import *  
import os
import threading
import multiprocessing
from functools import partial

#command : activateServer
serverStatus = False

    
def activateServer():
    global serverStatus
    if serverStatus == False :
        threading.Thread(target=os.system("python manage.py runserver 0.0.0.0:8000")).start()
        serverStatus = True
 
#creating the application main window.   
xMain = Tk()  
xMain.title("DIFT")
xMain.geometry("650x400")


#creating menu
xMenubar  = Menu(xMain)
file = Menu(xMenubar, tearoff=0)  
file.add_command(label="New")  
file.add_command(label="Open")  
file.add_command(label="Save")  
file.add_command(label="Save as...")  
file.add_command(label="Close")  
  
file.add_separator()  
  
file.add_command(label="Exit", command=xMain.quit)  
  
xMenubar.add_cascade(label="File", menu=file)  



edit = Menu(xMenubar, tearoff=0)  
edit.add_command(label="Undo")  
  
edit.add_separator()  
  
edit.add_command(label="Cut")  
edit.add_command(label="Copy")  
edit.add_command(label="Paste")  
edit.add_command(label="Delete")  
edit.add_command(label="Select All")  
  
xMenubar.add_cascade(label="Edit", menu=edit)

  
help = Menu(xMenubar, tearoff=0)  
help.add_command(label="About")  
xMenubar.add_cascade(label="Help", menu=help)  

mode = Menu(xMenubar, tearoff=0)  
mode.add_command(label="Server Mode", command=activateServer)  
mode.add_command(label="Kill Server")  

xMenubar.add_cascade(label="Mode", menu=mode)  

  
xMain.config(menu=xMenubar)  







#creating frame 
xFrame = Frame(xMain, bd=10)
xFrame.pack()
#Entering the event main loop  
xMain.mainloop()  